package compilator.object.expression;

public interface IExpression
{
    public int getOperatorCode();
}

package compilator.enums;

public enum EMethodReturnType
{
    VOID,
    BOOLEAN,
    INT
}

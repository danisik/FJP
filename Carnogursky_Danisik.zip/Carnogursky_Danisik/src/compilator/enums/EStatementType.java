package compilator.enums;

public enum EStatementType
{
    DO_WHILE,
    FOR,
    IF,
    WHILE,
    REPEAT_UNTIL,
    SWITCH,
    ASSIGMENT,
    METHOD_CALL,
    DECLARATION
}

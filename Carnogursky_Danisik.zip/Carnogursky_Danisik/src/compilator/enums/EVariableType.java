package compilator.enums;

public enum EVariableType
{
    INT,
    BOOLEAN
}

mvn clean install
java -jar target/SimpleJava-1.0-jar-with-dependencies.jar testFiles/aritmetic/basic.txt output.txt